#!/bin/bash

#RUNS=25 # 25*4 = 100
#OPPS_PERCENT=25
#
#	#nohup yarn jar $MAPRED_EXAMPLES wordcount -Dmapreduce.job.num-opportunistic-maps-percent="0" /wordcount/input/40G-file.txt /wordcount/output/wc_$(date +%s) &
echo "------------------------------------------"
echo "RUNNING 20G WORDCOUNT"
echo "------------------------------------------"
for i in {1..25}
do
	declare -a pids
	echo "--------------------[$i]-----------------------------"
	nohup yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/20G-file.txt /wordcount/output/wc_$(date +%s) &
	pids+=($!)
	nohup yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/20G-file.txt /wordcount/output/wc_$(date +%s) &
	pids+=($!)
	nohup yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/20G-file.txt /wordcount/output/wc_$(date +%s) &
	pids+=($!)
	nohup yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/20G-file.txt /wordcount/output/wc_$(date +%s) &
	pids+=($!)
	wait ${pids[@]}
	pids=""
done

mkdir wc_20G_50_over
pushd wc_20G_50_over
python3 /experiment/get_experiment_data.py
hadoop fs -get /tmp ./staging 
touch README
echo "Wordcount - 20G - 50% CPU O/D" >  ./README 
popd
tar -czvf wordcount_20g_50.tar.gz wc_20G_50_over
#/experiment/reset.sh
echo "------------------------------------------"
echo "DONE 20G WORDCOUNT"
echo "------------------------------------------"


#echo "------------------------------------------"
#echo "RUNNING 40G WORDCOUNT"
#echo "------------------------------------------"
#for i in {1..25}
#do
#	declare -a pids
#	echo "--------------------[$i]-----------------------------"
#	nohup yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/40G-file.txt /wordcount/output/wc_$(date +%s) &
#	pids+=($!)
#	nohup yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/40G-file.txt /wordcount/output/wc_$(date +%s) &
#	pids+=($!)
#	nohup yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/40G-file.txt /wordcount/output/wc_$(date +%s) &
#	pids+=($!)
#	nohup yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/40G-file.txt /wordcount/output/wc_$(date +%s) &
#	pids+=($!)
#	wait ${pids[@]}
#	pids=""
#done
#
#mkdir wc_40G_50_over
#pushd wc_40G_50_over
#python3 /experiment/get_experiment_data.py
#hadoop fs -get /tmp ./staging 
#touch README
#echo "Wordcount - 40G - 50% CPU O/D" >  ./README 
#popd
#tar -czvf wordcount_40g_50.tar.gz wc_40G_50_over
#/experiment/reset.sh
#echo "------------------------------------------"
#echo "DONE 40G WORDCOUNT"
#echo "------------------------------------------"
