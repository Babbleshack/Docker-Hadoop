#!/bin/bash

RUNS=25 # 25*4 = 100
N_MAPS=200
N_SAMPLES=999999999
OPP_PERCENT=0

hadoop fs -mkdir -p /
for i in {1..50}
do
	declare -a pids
	echo "--------------------[$i]-----------------------------"
	nohup yarn jar $MAPRED_EXAMPLES pi -Dmapreduce.job.num-opportunistic-maps-percent="$OPP_PERCENT" $N_MAPS $N_SAMPLES &
	pids+=($!)
	nohup yarn jar $MAPRED_EXAMPLES pi -Dmapreduce.job.num-opportunistic-maps-percent="$OPP_PERCENT" $N_MAPS $N_SAMPLES &
	pids+=($!)
	nohup yarn jar $MAPRED_EXAMPLES pi -Dmapreduce.job.num-opportunistic-maps-percent="$OPP_PERCENT" $N_MAPS $N_SAMPLES &
	pids+=($!)
	nohup yarn jar $MAPRED_EXAMPLES pi -Dmapreduce.job.num-opportunistic-maps-percent="$OPP_PERCENT" $N_MAPS $N_SAMPLES &
	pids+=($!)
	wait ${pids[@]}
	pids=""
done

