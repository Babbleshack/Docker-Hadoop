#!/bin/bash
set -e #exit on error
source env.sh

#hadoop jar $GRIDMIX -Dgridmix.job.type=SLEEPJOB /gridmix file:///experiment/rumen/trace.json
#hadoop fs -get /tmp gridmix_long
#python3 /experiment/get_experiment_data.py
#echo "centralised\n153 maps\n0% opps" > ./gridmix_long/README
#tar -czf gridmix_wc_long_0p.tar.gz ./history ./gridmix_long
#rm -rf history gridmix_long
#/experiment/reset.sh
#
#hadoop jar $GRIDMIX -Dmapreduce.job.num-opportunistic-maps-percent="25" -Dgridmix.job.type=SLEEPJOB /gridmix file:///experiment/rumen/trace.json
#hadoop fs -get /tmp gridmix_long
#python3 /experiment/get_experiment_data.py
#echo "centralised\n153 maps\n25% opps" > ./gridmix_long/README
#tar -czvf gridmix_wc_long_25p.tar.gz ./history ./gridmix_long
#rm -rf history gridmix_long
#/experiment/reset.sh
#
#hadoop jar $GRIDMIX -Dmapreduce.job.num-opportunistic-maps-percent="50" -Dgridmix.job.type=SLEEPJOB /gridmix file:///experiment/rumen/trace.json
#hadoop fs -get /tmp gridmix_long
#python3 /experiment/get_experiment_data.py
#echo "centralised\n153 maps\n50% opps" > ./gridmix_long/README
#tar -czvf gridmix_wc_long_50p.tar.gz ./history ./gridmix_long
#rm -rf history gridmix_long
#/experiment/reset.sh

#hadoop jar $GRIDMIX -Dmapreduce.job.num-opportunistic-maps-percent="75" -Dgridmix.job.type=SLEEPJOB /gridmix file:///experiment/rumen/trace.json
#hadoop fs -get /tmp gridmix_long
#python3 /experiment/get_experiment_data.py
#touch ./gridmix_long/README
#echo "centralised\n153 maps\n75% opps" > ./gridmix_long/README
#tar -czvf gridmix_wc_long_75p.tar.gz ./history ./gridmix_long
#rm -rf history gridmix_long
#/experiment/reset.sh

#hadoop jar $GRIDMIX -Dmapreduce.job.num-opportunistic-maps-percent="100" -Dgridmix.job.type=SLEEPJOB /gridmix file:///experiment/rumen/trace.json
#hadoop fs -get /tmp gridmix_long
#python3 /experiment/get_experiment_data.py
#touch ./gridmix_long/README
echo "centralised\n153 maps\n100% opps" > ./gridmix_long/README
tar -czvf gridmix_wc_long_100p.tar.gz ./history ./gridmix_long
rm -rf history gridmix_long
/experiment/reset.sh
