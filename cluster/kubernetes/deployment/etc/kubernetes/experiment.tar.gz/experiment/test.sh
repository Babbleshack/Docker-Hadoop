set -e

#echo "RUNNING DIST-25"
#source /experiment/env.sh
#yarn --config /yarn-conf/hadoop jar $GRIDMIX \
#	-Dgridmix.job.type=SLEEPJOB \
#	-Dgridmix.slepp.maptask-only=true \
#	-Dgridmix.sleep.max-map-time=1500 \
#	-Dmapreduce.job.num-opportunistic-maps-percent=25 \
#	/gridmix file:///experiment/rumen/200j-200t-short-trace.json  
#mkdir -pv /experiment/distributed/DIST-25/
#pushd /experiment/distributed/DIST-25
#python3 /experiment/get_experiment_data.py
#hadoop fs -get /tmp ./staging
#popd
#tar -cvzf DIST-25.tar.gz /experiment/distributed/DIST-25
#mv DIST-25.tar.gz /experiment/archive
#/experiment/reset.sh
#echo "FINISH DIST-25"

run-gridmix () {
	echo "RUNNING DIST-$1"
	source /experiment/env.sh
	yarn --config /yarn-conf/hadoop jar $GRIDMIX \
		-Dgridmix.job.type=SLEEPJOB \
		-Dgridmix.slepp.maptask-only=true \
		-Dgridmix.sleep.max-map-time=1500 \
		-Dmapreduce.job.num-opportunistic-maps-percent=$1 \
		/gridmix file:///experiment/rumen/200j-200t-short-trace.json  
	mkdir -pv /experiment/distributed/DIST-$1/
	pushd /experiment/distributed/DIST-$1
	python3 /experiment/get_experiment_data.py
	hadoop fs -get /tmp ./staging
	popd
	tar -cvzf DIST-$1.tar.gz /experiment/distributed/DIST-$1
	mv DIST-$1.tar.gz /experiment/archive
	/experiment/reset.sh
	echo "FINISH DIST-$1"
}

run-gridmix 50
