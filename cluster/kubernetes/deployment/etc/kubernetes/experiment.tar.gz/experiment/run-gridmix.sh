set -e

	#-Dgridmix.sleep.max-map-time=29000 \

run-gridmix () {
	echo "RUNNING DIST-$1"
	source /experiment/env.sh
	/experiment/reset.sh
	yarn --config /yarn-conf/hadoop jar $GRIDMIX \
		-Dgridmix.job.type=SLEEPJOB \
		-Dgridmix.slepp.maptask-only=true \
		-Dgridmix.sleep.max-map-time=1500 \
		-Dmapreduce.job.num-opportunistic-maps-percent=$1 \
		/gridmix file:///experiment/rumen/200j-200t-short-trace.json  
		#/gridmix file:///experiment/gridmix/rumen/long-153t-trace.json
	mkdir -pv /experiment/distributed/short/DIST-$1/
	pushd /experiment/distributed/short/DIST-$1
	python3 /experiment/get_experiment_data.py &> /dev/null
	hadoop fs -get /tmp ./staging
	popd
	tar -cvzf DIST-$1.tar.gz /experiment/distributed/short/DIST-$1
	mv DIST-$1.tar.gz /experiment/archive
	echo "FINISH DIST-$1"
}

run-gridmix 0
run-gridmix 25
run-gridmix 50
run-gridmix 75
run-gridmix 100
