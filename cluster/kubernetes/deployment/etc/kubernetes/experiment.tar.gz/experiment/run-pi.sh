#!/bin/bash

set -e

RUNS=25 # 25*4 = 100
N_MAPS=200
N_SAMPLES=9999
OPP_PERCENT=0

YARN="yarn --config /yarn-conf/hadoop" 

#for i in {1..50}
#do
#	declare -a pids
#	echo "--------------------[$i]-----------------------------"
#	nohup yarn jar $MAPRED_EXAMPLES pi -Dmapreduce.job.num-opportunistic-maps-percent="$OPP_PERCENT" $N_MAPS $N_SAMPLES &
#	pids+=($!)
#	nohup yarn jar $MAPRED_EXAMPLES pi -Dmapreduce.job.num-opportunistic-maps-percent="$OPP_PERCENT" $N_MAPS $N_SAMPLES &
#	pids+=($!)
#	nohup yarn jar $MAPRED_EXAMPLES pi -Dmapreduce.job.num-opportunistic-maps-percent="$OPP_PERCENT" $N_MAPS $N_SAMPLES &
#	pids+=($!)
#	nohup yarn jar $MAPRED_EXAMPLES pi -Dmapreduce.job.num-opportunistic-maps-percent="$OPP_PERCENT" $N_MAPS $N_SAMPLES &
#	pids+=($!)
#	wait ${pids[@]}
#	pids=""
#done
for i in {1..50}
do
	declare -a pids
	echo "--------------------[$i]-----------------------------"
	nohup $YARN jar $MAPRED_EXAMPLES pi  $N_MAPS $N_SAMPLES &
	pids+=($!)
	nohup $YARN jar $MAPRED_EXAMPLES pi  $N_MAPS $N_SAMPLES &
	pids+=($!)
	nohup $YARN jar $MAPRED_EXAMPLES pi  $N_MAPS $N_SAMPLES &
	pids+=($!)
	nohup $YARN jar $MAPRED_EXAMPLES pi  $N_MAPS $N_SAMPLES &
	pids+=($!)
	wait ${pids[@]}
	pids=""
done
mkdir -pv /experiment/distributed/benchmark-quasipi-200
pushd /experiment/distributed/benchmark-quasipi-200
python3 /experiment/get_experiment_data.py
hadoop fs -get /tmp ./staging
#/experiment/reset.sh
