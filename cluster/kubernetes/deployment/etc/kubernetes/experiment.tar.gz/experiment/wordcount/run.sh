#!/bin/bash

RUNS=25 # 25*4 = 100

hadoop fs -mkdir -p /
for i in {1..25}
do
	declare -a pids
	echo "--------------------[$i]-----------------------------"
	yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/20G-file.txt /wordcount/output/wc_$(date +%s) 2>&1 > /dev/null &
	pids+=($!)
	yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/20G-file.txt /wordcount/output/wc_$(date +%s) 2>&1 > /dev/null &
	pids+=($!)
	yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/20G-file.txt /wordcount/output/wc_$(date +%s) 2>&1 > /dev/null &
	pids+=($!)
	yarn jar $MAPRED_EXAMPLES wordcount /wordcount/input/20G-file.txt /wordcount/output/wc_$(date +%s) 2>&1 > /dev/null &
	pids+=($!)
	for pid in "${pids[@]}"
	do
		wait pid
	done
done

